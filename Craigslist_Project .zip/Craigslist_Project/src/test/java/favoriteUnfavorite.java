import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.*;



public class favoriteUnfavorite {

    private WebDriver driver;



    @BeforeClass

    public void setUp() {

        driver = new ChromeDriver();
        driver.manage().window().maximize();

    }



    @Test (priority = 1)
    public void loginCorrectly() throws InterruptedException {

        driver.get("https://accounts.craigslist.org/login"); //correct login
        driver.findElement(By.id("inputEmailHandle")).sendKeys("softwaretestingfgcu@gmail.com");
        Thread.sleep(3000);

        driver.findElement(By.id("inputPassword")).sendKeys("Craiglist@2025");
        Thread.sleep(3000);

        driver.findElement(By.id("login")).click();
        Thread.sleep(3000);



        // Locate the link by visible text

        WebElement link = driver.findElement(By.linkText("craigslist"));

        link.click();

        Thread.sleep(2000);

    }



    @Test(priority = 2, dependsOnMethods = {"loginCorrectly"})

    public void eventCalendar() throws InterruptedException {

        Thread.sleep(3000);

        // Assumes you are now logged in and on the account home page

        // takes you to the event calendar

        WebElement link = driver.findElement(By.linkText("event calendar"));

        link.click();

        Thread.sleep(2000);

    }



    @Test(priority = 3, dependsOnMethods = {"eventCalendar"})

    public void selectEvent() throws InterruptedException {

        WebElement link = driver.findElement(By.linkText("Hadestown Musical $25"));

        link.click();

        Thread.sleep(2000);



    }



    @Test(priority = 4, dependsOnMethods = {"firstSelection"})

    public void favorite() throws InterruptedException {

        // add to favorites

        WebElement favorite = driver.findElement(By.xpath("/html/body/section/section/header/div[2]/div/div[2]/div[1]/div[2]"));

        favorite.click();

        Thread.sleep(2000);



    }



    @Test(priority = 5, dependsOnMethods = {"favorite"})

    public void goToFavorites() throws InterruptedException {

        // go to favorites

        WebElement link = driver.findElement(By.linkText("2 favorites"));

        link.click();

        Thread.sleep(2000);

    }



    @Test(priority = 6, dependsOnMethods = {"goToFavorites"})

    public void unfavorite() throws InterruptedException {

        WebElement star = driver.findElement(By.xpath("//*[@id=\"search-results-1\"]/div[2]/div/button/span"));

        star.click();

        Thread.sleep(2000);

    }



    //close driver

    @AfterClass

    public void tearDown() {

        driver.quit();

    }



} 

 